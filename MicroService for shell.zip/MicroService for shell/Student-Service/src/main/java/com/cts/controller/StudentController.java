package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cts.model.Student;

import java.util.*;
@RestController
@RequestMapping("/student")
public class StudentController {
	private static Map<String,List<Student>> m=new HashMap();
	@Autowired
    Environment environment;
	static
	{
		List<Student> st=new ArrayList();
		Student st1=new Student("ann","class 3");
		Student st2=new Student("ben","class 4");
		st.add(st1);
		st.add(st2);
		m.put("abcschool",st);
		
		List<Student> st0=new ArrayList();
		Student st3=new Student("kenn","class 4");
		Student st4=new Student("denn","class 5");
		st0.add(st3);
		st0.add(st4);
		m.put("xyzschool",st0);
		
		
		
	}
	
	@GetMapping(value="/getStudentdetailsForSchool/{schoolname}")
	public List<Student> getStudents(@PathVariable String schoolname)
	{
		List<Student> st3=null;
		List<Student>st=null;
		boolean flag=false;
		try {
		System.out.println("Bags,I am called");
		st=m.get(schoolname);
		if(st==null)
		{
			st3=new ArrayList();
			Student st5=new Student("Not Found","N/A");
			st3.add(st5);
			
			//return st3;
		}
		else
		{
			System.out.println(st.toString());
			flag=true;
			//return st;
		}
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(flag==true)
		{
			return st;
		}
		else
		{
			return st3;
		}
		
	}
	
	@GetMapping(value="/getStudentdetailsForSchool1/{schoolname}")
	public String getStudents1(@PathVariable String schoolname)
	{
		return "hi bhagya"+"you r from"+schoolname;
	}
	@GetMapping(value="/getStudentdetailsForSchool2/{name}")
	public String getStudents2(@PathVariable String name)
	{
		return "hi rucha"+"you belong to "+name;
	}
	
	

    @GetMapping("/data")
    public String getStudentPort() {

       return "data of STUDENT-SERVICE, Running on port: "
         +environment.getProperty("local.server.port");
    }
   
	
}
