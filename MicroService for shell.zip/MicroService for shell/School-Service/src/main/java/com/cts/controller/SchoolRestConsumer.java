package com.cts.controller;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cts.model.Student;

import java.util.*;


@FeignClient(name="Student-Service")

public interface SchoolRestConsumer {


      @GetMapping("student/getStudentdetailsForSchool/{schoolname}")
      public List<Student> getStudentsBySchoolName(@PathVariable String  schoolname);
      
      @GetMapping(value="/getStudentdetailsForSchool2/{name}")
      public String replyhello(@PathVariable String name);

     @GetMapping("/data")
     public String findPort();
}