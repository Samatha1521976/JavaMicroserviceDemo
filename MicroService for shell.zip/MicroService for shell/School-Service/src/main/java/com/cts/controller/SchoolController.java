package com.cts.controller;
import java.util.*;
import java.io.IOException;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import java.util.*;

import com.cts.model.Student;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;
@RestController
@RequestMapping("/school")
public class SchoolController {

	//@Autowired
	RestTemplate restTemplate;
	@Autowired
	SchoolRestConsumer consumer;
	

	
	@GetMapping(value="/getSchoolDetails/{schoolname}")
	public List<Student> getStudents(@PathVariable String schoolname)
	{
		System.out.println("Schoolname is Bags:"+schoolname);
		
		
		
		/*ResponseEntity<String> responseEntity = new RestTemplate().getForEntity(
			        "http://localhost:7100/student/getStudentdetailsForSchool1/{schoolname}", String.class,schoolname);*/
	/*	ResponseEntity<Student[]> responseEntity = new RestTemplate().getForEntity(
		        "http://localhost:7100/student/getStudentdetailsForSchool/{schoolname}", Student[].class,schoolname);*/
		
	/*	List<Student> st = (List<Student>) new RestTemplate().getForEntity(
		        "http://localhost:7100/student/getStudentdetailsForSchool/{schoolname}", Student.class,schoolname);
		  
	return st;*/

			  // String response = responseEntity.getBody();
//return response;
		return consumer.getStudentsBySchoolName(schoolname);
		
		
	}
	@GetMapping("/sayhello/{name}")
	public String sayhello(@PathVariable String name)
	{
		return consumer.replyhello(name);
	}
	
	@GetMapping("/findport")
	public String sayhello2()
	{
		return consumer.findPort();
	}
		
	private static HttpEntity<?> getHeaders() throws IOException
	{
		HttpHeaders headers=new HttpHeaders();
		headers.set("Accept",MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}

	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	    
	}
}
